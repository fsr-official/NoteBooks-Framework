import path from 'path';
import { promises as fs } from 'fs';

// Import helpers from repo-registry and pages-fetch. Use runtime paths that
// work both when running compiled JS and under ts-node during build.
async function loadHelpers() {
  try {
    const rr = await import('../api/repo-registry.js');
    const pf = await import('../api/pages-fetch.js');
    return { loadRepoRegistry: rr.loadRepoRegistry || rr.default?.loadRepoRegistry, resolvePagesBaseUrl: pf.resolvePagesBaseUrl || pf.default?.resolvePagesBaseUrl, fetchRepoManifest: pf.fetchRepoManifest || pf.default?.fetchRepoManifest };
  } catch (e) {
    const rr = await import('../api/repo-registry.ts');
    const pf = await import('../api/pages-fetch.ts');
    return { loadRepoRegistry: (rr as any).loadRepoRegistry, resolvePagesBaseUrl: (pf as any).resolvePagesBaseUrl, fetchRepoManifest: (pf as any).fetchRepoManifest };
  }
}

function isMarkdown(name: string) {
  return /\.mdx?$|\.markdown$/i.test(name);
}

function isPdf(name: string) {
  return /\.pdf$/i.test(name);
}

function rawUrlFor(owner: string, repoName: string, branch: string, filePath: string) {
  const normalized = String(filePath || '').replace(/^\/+/, '');
  return `https://raw.githubusercontent.com/${owner}/${repoName}/${branch}/${normalized}`;
}

function subjectFromStream(stream: unknown): string | null {
  const normalized = String(stream || '').trim().toLowerCase();
  if (normalized === 'science' || normalized === 'commerce' || normalized === 'humanities') {
    return normalized;
  }
  if (normalized === 'humanity' || normalized === 'arts') return 'humanities';
  return null;
}

function inferSubjectFromRepository(repo: string): string | null {
  const normalized = repo.toLowerCase();
  if (normalized.includes('science')) return 'science';
  if (normalized.includes('commerce')) return 'commerce';
  if (normalized.includes('humanities') || normalized.includes('humanity') || normalized.includes('arts')) return 'humanities';
  return null;
}

const FETCHABLE_EXTENSIONS = /\.(?:md|mdx|markdown|pdf)$/i;

async function fetchGithubTreeManifest(repo: string, branch: string) {
  const token = String(process.env.GITHUB_TOKEN || process.env.GITHUB_PAT || '').trim();
  const headers: Record<string, string> = {
    Accept: 'application/vnd.github+json',
    'User-Agent': 'NoteBooks-subject-tree-generator'
  };
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`https://api.github.com/repos/${repo}/git/trees/${encodeURIComponent(branch)}?recursive=1`, { headers });
  if (!response.ok) throw new Error(`GitHub tree fetch failed with ${response.status}`);
  const payload: any = await response.json();
  return (Array.isArray(payload?.tree) ? payload.tree : [])
    .filter((entry: any) => entry?.type === 'blob' && FETCHABLE_EXTENSIONS.test(String(entry.path || '')))
    .map((entry: any) => {
      const filePath = String(entry.path || '').replace(/^\/+/, '');
      return { path: filePath, name: filePath.split('/').pop() || filePath, size: entry.size || null };
    });
}

async function main() {
  try {
    const { loadRepoRegistry, resolvePagesBaseUrl, fetchRepoManifest } = await loadHelpers();
    if (typeof loadRepoRegistry !== 'function' || typeof fetchRepoManifest !== 'function') throw new Error('registry or manifest helpers not available');

    const entries = await loadRepoRegistry();
    // Subject targets
    const subjects = ['science', 'commerce', 'humanities'];
    const trees: Record<string, any[]> = { science: [], commerce: [], humanities: [] };

    for (const entry of entries || []) {
      const repo = String(entry.repo || '');
      const subjectKey = entry.stream
        ? subjectFromStream(entry.stream)
        : inferSubjectFromRepository(repo);
      if (!subjectKey) {
        console.warn(`[subject-trees] skipping ${repo} — invalid or missing STREAM mapping`);
        continue;
      }

      const pagesBase = resolvePagesBaseUrl ? resolvePagesBaseUrl(entry) : '';
      if (!pagesBase) {
        console.log(`[subject-trees] skipping ${repo} — no Pages base URL`);
        continue;
      }

      try {
        const [owner, repoName] = repo.split('/');
        const branch = entry.branch || 'main';
        let manifest: any[];
        try {
          manifest = await fetchRepoManifest(repo, repoName || '', branch, pagesBase);
          console.log(`[subject-trees] loaded files.json for ${repo}`);
        } catch (manifestError: any) {
          console.warn(`[subject-trees] files.json unavailable for ${repo}; using GitHub tree fallback:`, manifestError?.message || manifestError);
          manifest = await fetchGithubTreeManifest(repo, branch);
        }
        if (!Array.isArray(manifest) || manifest.length === 0) {
          console.log(`[subject-trees] repository tree empty for ${repo}; skipping`);
          continue;
        }

        
        // Ensure a repo node exists for this subject
        let repoNode = (trees as any)[subjectKey].find((r: any) => r.repo === repo);
        if (!repoNode) {
          repoNode = {
            repo,
            branch,
            pagesBase: pagesBase,
            tree: { type: 'folder', name: repoName, children: [] }
          };
          (trees as any)[subjectKey].push(repoNode);
        }

        // Insert files into nested folders under repoNode.tree
        for (const item of manifest) {
          const p = String(item.path || item.name || '');
          if (!p)
            continue;
          if (!(isMarkdown(p) || isPdf(p)))
            continue;

          const parts = p.split('/').filter(Boolean);
          const fileName = parts[parts.length - 1];
          const fileEntry = {
            type: 'file',
            name: item.name || fileName,
            path: p,
            mime: isPdf(p) ? 'application/pdf' : 'text/markdown',
            repo,
            branch,
            raw: rawUrlFor(owner, repoName, branch, p),
            size: item.size || null
          };

          // Insert into nested tree
          let node = repoNode.tree;
          for (let i = 0; i < parts.length - 1; i++) {
            const part = parts[i];
            node.children = node.children || [];
            let next = node.children.find((c: any) => c.type === 'folder' && c.name === part);
            if (!next) {
              next = { type: 'folder', name: part, children: [] };
              node.children.push(next);
            }
            node = next;
          }
          node.children = node.children || [];
          node.children.push(fileEntry);
        }
      } catch (err: any) {
        console.warn(`[subject-trees] failed to build tree for ${repo}:`, err?.message || err);
        continue;
      }
    }

    // Write out per-subject JSON files under public/
    for (const s of subjects) {
      const out = path.resolve(process.cwd(), 'public', `${s}-tree.json`);
      const outJson = path.resolve(process.cwd(), 'public', 'json', `${s}-tree.json`);
      try {
        await fs.mkdir(path.dirname(out), { recursive: true });
        // Use the format: { subject, repos: [ { repo, branch, pagesBase, tree } ] }
        const payload = { subject: s, repos: (trees as any)[s] };
        await fs.writeFile(out, JSON.stringify(payload, null, 2), 'utf8');
        console.log(`[subject-trees] wrote ${out} (${(trees as any)[s].length} repo entries)`);
        // Also write to organized public/json folder for runtime consumption
        await fs.mkdir(path.dirname(outJson), { recursive: true });
        await fs.writeFile(outJson, JSON.stringify(payload, null, 2), 'utf8');
        console.log(`[subject-trees] wrote ${outJson} (${(trees as any)[s].length} repo entries)`);
      } catch (e) {
        console.warn(`[subject-trees] failed to write ${out}:`, e?.message || e);
      }
    }

    console.log('[subject-trees] generation complete');
    process.exit(0);
  } catch (err: any) {
    console.error('[subject-trees] failed:', err?.message || err);
    process.exit(1);
  }
}

main();
