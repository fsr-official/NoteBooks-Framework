#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const REG_PATH = path.join(ROOT, 'repo-registry.json');
const OUT_DIR = path.join(ROOT, 'public');

function detectStream(name) {
  if (!name) return 'misc';
  const n = name.toLowerCase();
  if (n.includes('science')) return 'science';
  if (n.includes('commerce')) return 'commerce';
  if (n.includes('humanities')) return 'humanities';
  if (n.includes('community')) return 'community';
  if (n.includes('volunteers')) return 'volunteers';
  if (n.includes('accounts')) return 'accounts';
  if (n.includes('issues')) return 'issues';
  return 'misc';
}

function pagesBaseFromRepo(repo) {
  if (!repo) return '';
  const parts = repo.split('/');
  if (parts.length !== 2) return '';
  const owner = parts[0];
  const repoName = parts[1];
  return `https://${owner}.github.io/${repoName}/`;
}

function readRegistry() {
  if (!fs.existsSync(REG_PATH)) {
    console.error('repo-registry.json not found at', REG_PATH);
    process.exit(1);
  }
  const raw = fs.readFileSync(REG_PATH, 'utf8');
  return JSON.parse(raw);
}

function collect(reg) {
  const buckets = {};
  const children = reg.children || [];
  children.forEach((child) => {
    const stream = detectStream(child.name || child.repo || 'misc');
    if (!buckets[stream]) buckets[stream] = [];
    const repoEntry = {
      repo: child.repo || null,
      branch: child.branch || 'main',
      pagesBase: child.pagesBase || (child.repo ? pagesBaseFromRepo(child.repo) : ''),
      tree: child
    };
    buckets[stream].push(repoEntry);
  });
  return buckets;
}

function writeBuckets(buckets) {
  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });
  Object.keys(buckets).forEach((stream) => {
    const out = {
      subject: stream,
      repos: buckets[stream]
    };
    const outPath = path.join(OUT_DIR, `${stream}-tree.json`);
    fs.writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8');
    console.log('Wrote', outPath);
  });
}

function main() {
  const reg = readRegistry();
  const buckets = collect(reg);
  writeBuckets(buckets);
}

main();
